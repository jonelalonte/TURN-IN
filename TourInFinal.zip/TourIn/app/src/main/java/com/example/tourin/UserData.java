package com.example.tourin;

public class UserData {
    public static final String KEY_USER_TYPE = "user_type";
}
