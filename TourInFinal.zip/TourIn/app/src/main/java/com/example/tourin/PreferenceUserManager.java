package com.example.tourin;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.tourin.Constants;

public class PreferenceUserManager {

    private final SharedPreferences sharedPreferences;

    public PreferenceUserManager(Context context){
        sharedPreferences = context.getSharedPreferences(Constants.KEY_PREFERENCE_NAME,Context.MODE_PRIVATE);
    }

    public void putString(String key, String value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();

    }
    public String getString(String key){
        return sharedPreferences.getString(key, null);

    }
}
