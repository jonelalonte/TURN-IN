package com.example.tourin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;

import com.example.tourin.databinding.ActivityProfileBinding;
import java.text.DateFormat;
import java.util.Calendar;

public class ProfileActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    ActivityProfileBinding binding;
    public ImageView imageView, imageUpload;
    public ImageView profilePic, profilePicButton;
    public EditText etusername, etfn, etmi, etln, etemail, etaddress, etbirthdate;

    public Button editB, updateB;

    private static final int REQUEST_PERMISSION = 1;
    private static final int REQUEST_IMAGE = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        binding =ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        etusername = (EditText) findViewById(R.id.etprofile_username);
        etfn = (EditText) findViewById(R.id.etprofile_name);
        etmi = (EditText) findViewById(R.id.etprofile_mi);
        etln = (EditText) findViewById(R.id.etprofile_lastname);
        etemail = (EditText) findViewById(R.id.etprofile_email);
        etaddress = (EditText) findViewById(R.id.etprofile_address);
        etbirthdate = (EditText) findViewById(R.id.etprofile_birthdate);

        editB =(Button) findViewById(R.id.profile_edit_button);
        updateB =(Button) findViewById(R.id.profile_update_button);

        imageView = (ImageView) findViewById(R.id.ivprofile_birthdate);

        profilePicButton = (ImageView) findViewById(R.id.iv_profile_image_icon);
        profilePic = (ImageView) findViewById(R.id.iv_profile_image);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });


        editB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("You can not Edit yor profile");
                etusername.setEnabled(true);
                etfn.setEnabled(true);
                etmi.setEnabled(true);
                etln.setEnabled(true);
                etemail.setEnabled(true);
                etaddress.setEnabled(true);
                profilePicButton.setEnabled(true);
                if (!updateB.isEnabled()) {
                    updateB.setEnabled(true);
                    editB.setEnabled(false);
                }

                profilePicButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (updateB.isEnabled()){
                            if (ContextCompat.checkSelfPermission(ProfileActivity.this,
                                    Manifest.permission.READ_EXTERNAL_STORAGE) ==
                                    PackageManager.PERMISSION_GRANTED) {
                                selectImage();
                            }
                            else {
                                ActivityCompat.requestPermissions(ProfileActivity.this,
                                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                        REQUEST_PERMISSION);
                            }
                        }
                    }
                });
            }

        });

        updateB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etusername.setEnabled(false);
                etfn.setEnabled(false);
                etmi.setEnabled(false);
                etln.setEnabled(false);
                etemail.setEnabled(false);
                etaddress.setEnabled(false);
                profilePicButton.setEnabled(false);

                if (!editB.isEnabled()) {
                    editB.setEnabled(true);
                    updateB.setEnabled(false);
                }
            }
        });
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectImage();
            } else {
                Toast.makeText(this, "Permission denied. Cannot select image.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                        profilePic.setImageBitmap(bitmap);
                        // You can now upload the image to a server or perform other actions with it.
                    } catch (Exception e) {
                        Log.e("ImageUpload", "Error loading image: " + e.getMessage());
                    }
                }
            }
        }
    }
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month);
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        TextView textView = (TextView) findViewById(R.id.etprofile_birthdate);

        String year_string = Integer.toString(year);
        String month_string = Integer.toString(month + 1);
        String day_string = Integer.toString(dayOfMonth);

        String date_message = ("BirthDate: "+ month_string + "/" + day_string +"/"+ year_string);
//        String currentDateString = DateFormat.getDateInstance(DateFormat.FULL).format(cal.getTime());

        if (etfn.isEnabled()) {
            textView.setText(date_message);
        } else {
            textView.setEnabled(false);
            textView.setText("Birthdate: MM/DD/YYYY");
        }
//        Toast.makeText(this, date_message, Toast.LENGTH_SHORT).show();
    }

    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}